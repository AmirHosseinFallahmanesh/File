﻿namespace Demo.Core.Enitites
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; }
    }
}
