﻿namespace Demo.Core.Enitites
{
    public enum OrderState
    {
        Pending,
        Accept,
        Failed
    }
}