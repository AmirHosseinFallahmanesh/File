﻿namespace Demo.Core.Enitites
{
    public class Store
    {
        public int StoreId { get; set; }

        public string Name { get; set; }
        public bool Type { get; set; }
       
    }
}
